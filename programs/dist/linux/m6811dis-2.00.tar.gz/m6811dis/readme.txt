The Linux version of M6811DIS was compiled against LSB
(Linux Standard Base).  To guarantee runability, install
LSB:
sudo apt-get install lsb
